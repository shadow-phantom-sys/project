package org.reni.controller;

import java.util.List;

import org.reni.model.Employee;
import org.reni.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/")
	public String showIndexPage(Model model) {
		
		List<Employee> employees=employeeService.getAllEmployees();
		model.addAttribute("employees", employees);
		
		return "index";
	}
}
