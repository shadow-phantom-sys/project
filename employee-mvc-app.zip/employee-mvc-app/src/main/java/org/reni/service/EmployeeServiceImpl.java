package org.reni.service;

import java.lang.StackWalker.Option;
import java.util.List;
import java.util.Optional;

import org.reni.model.Employee;
import org.reni.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
	}
	
	@Override
	public Employee getEmployeeById(int id) {
		
//		Optional<Employee> optEmployee=employeeRepository.findById(id);
//		Employee employee=optEmployee.get();
//		return employee;
		return employeeRepository.findById(id).get();
	}
	
	@Override
	public void saveEmployee(Employee employee) {
		
		employeeRepository.save(employee);
	}
	
	@Override
	public void deleteEmployee(int id){
		employeeRepository.deleteById(id);
	}
}
